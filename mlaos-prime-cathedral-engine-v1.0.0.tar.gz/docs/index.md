# Architecture & Taxonomy

The structural layout and geological strata of the **MLAOS-Prime Cathedral Engine**:

* **[src/main/core/](http://127.0.0.1:8002/)**: The Sanctum of Invariants—houses fundamental domain business logic, immutable Merkle DAG blocks, paraconsistent Belnap-Dunn state buffers, and mythotechnical translation matrices.
* **[src/main/utils/](http://127.0.0.1:8002/)**: The Pure Mathematical Choirs—contains deterministic helper functions with zero side effects for high-precision calculations like consciousness intensity ($d\Phi/dt$).
* **[src/main/services/](http://127.0.0.1:8002/)**: The Boundary Adapters—manages external adapters, Write-Ahead Logging (WAL) SQLite hooks, and anti-corruption infrastructure barriers.
* **[src/main/ingress/](http://127.0.0.1:8002/)**: The Sovereign Ingress Choirs—houses FastAPI protocol adapters, routing, and telemetry endpoints.
* **[tests/unit/](http://127.0.0.1:8002/)**: Discrete Verification Chambers—isolated, fast-running unit tests targeting discrete helper functions, DAG validation, logic state buffers, and translators.
* **[tests/integration/](http://127.0.0.1:8002/)**: Confluence & Persistence Vaults—validates end-to-end service interactions, database persistence loops, and API routing integrity.
