import pytest
from src.main.core.buffer import BelnapDunnStateBuffer

def test_belnap_dunn_dialetheic_resolution():
    buffer = BelnapDunnStateBuffer()
    
    status = buffer.ingest_telemetry_vector("flux_gate", True)
    assert status == "STATE_STABLE"
    assert buffer.evaluate_truth_value("flux_gate") == "TRUE"
    
    status = buffer.ingest_telemetry_vector("flux_gate", False, contradictory_override=True)
    assert status == "DIALETHEIC_COLLISION_CRYSTALLIZED"
    assert "BOTH" in buffer.evaluate_truth_value("flux_gate")
